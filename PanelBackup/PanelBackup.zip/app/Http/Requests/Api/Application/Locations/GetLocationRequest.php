<?php

namespace Pterodactyl\Http\Requests\Api\Application\Locations;

class GetLocationRequest extends GetLocationsRequest
{
}
