<?php

namespace Pterodactyl\Models;

class EggMount extends Model
{
    protected $table = 'egg_mount';

    protected $primaryKey = null;

    public $incrementing = false;
}
